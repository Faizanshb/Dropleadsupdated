/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Client } from "@notionhq/client";
import { NotionAPI } from "notion-client";

// Initialize Notion client for API access
const notion = new Client({
  auth: "ntn_g42323532305EHcE7iYPpkdByOqGRwe4G8Mv2wp7Quhg3G",
});

// Initialize unofficial Notion client for page content
const notionClient = new NotionAPI();

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content?: string;
  coverImage?: string;
  publishedDate: string;
  author: string;
  tags: string[];
  readTime: number;
  status: string;
  category: string;
}

export interface BlogCategory {
  name: string;
  count: number;
  color: string;
}

export interface PaginatedBlogPosts {
  posts: BlogPost[];
  totalPages: number;
  currentPage: number;
  totalPosts: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}

export async function getBlogDatabases() {
  try {
    const response = await notion.search({
      filter: {
        value: "database",
        property: "object",
      },
    });

    // console.log("Fetched databases:", JSON.stringify(response, null, 2));
    return response.results;
  } catch (error) {
    console.error("Error fetching databases:", error);
    return [];
  }
}

export async function getBlogCategories(): Promise<BlogCategory[]> {
  try {
    const databases = await getBlogDatabases();
    if (databases.length === 0) return [];

    const databaseId = databases[0].id;

    // Get all pages from the database
    const response = await notion.databases.query({
      database_id: databaseId,
      page_size: 100,
    });

    // Extract categories from posts (fallback to "General" if no category property)
    const categoryMap = new Map<string, number>();
    const colors = [
      "#4285F4",
      "#34A853",
      "#EA4335",
      "#FBBC04",
      "#9C27B0",
      "#FF9800",
    ];

    response.results.forEach((page: any) => {
      const category =
        page.properties.Category?.select?.name ||
        page.properties.Type?.select?.name ||
        "General";
      categoryMap.set(category, (categoryMap.get(category) || 0) + 1);
    });

    const categories: BlogCategory[] = Array.from(categoryMap.entries()).map(
      ([name, count], index) => ({
        name,
        count,
        color: colors[index % colors.length],
      })
    );

    // Add "All" category
    const totalPosts = response.results.length;
    categories.unshift({
      name: "All",
      count: totalPosts,
      color: "#4285F4",
    });

    return categories;
  } catch (error) {
    console.error("Error fetching categories:", error);
    return [{ name: "All", count: 0, color: "#4285F4" }];
  }
}

export async function getBlogPosts(
  page = 1,
  limit = 9,
  category?: string
): Promise<PaginatedBlogPosts> {
  try {
    const databases = await getBlogDatabases();
    if (databases.length === 0) {
      return {
        posts: [],
        totalPages: 0,
        currentPage: page,
        totalPosts: 0,
        hasNextPage: false,
        hasPreviousPage: false,
      };
    }

    const databaseId = databases[0].id;

    // Build filter - be flexible with property names
    let filter: any = undefined;

    if (category && category !== "All") {
      filter = {
        or: [
          {
            property: "Category",
            select: {
              equals: category,
            },
          },
          {
            property: "Type",
            select: {
              equals: category,
            },
          },
        ],
      };
    }

    // Get all results first to handle pagination manually
    const allResults = await notion.databases.query({
      database_id: databaseId,
      filter,
      sorts: [
        {
          property: "Date",
          direction: "descending",
        },
      ],
      page_size: 100,
    });


    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedResults = allResults.results.slice(startIndex, endIndex);
    
    const posts: BlogPost[] = paginatedResults.map((page: any) => {
      const properties = page.properties;



      // Be flexible with property names
      const title =
        properties.Name?.title?.[0]?.plain_text ||
        properties.Title?.title?.[0]?.plain_text ||
        "Untitled";

      const slug =
        properties.Slug?.rich_text?.[0]?.plain_text ||
        title
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/(^-|-$)/g, "") ||
        page.id;

      return {
        id: page.id,
        title,
        slug,
        excerpt:
          properties.Excerpt?.rich_text?.[0]?.plain_text ||
          properties.Description?.rich_text?.[0]?.plain_text ||
          "No excerpt available",
        coverImage:
          page?.cover?.external?.url || "",
        publishedDate:
          properties.Date?.date?.start ||
          properties["Published Date"]?.date?.start ||
          properties["Created Date"]?.date?.start ||
          new Date().toISOString(),
        author:
          properties.Author?.people?.[0]?.name ||
          properties.Writer?.people?.[0]?.name ||
          "DropLeads Team",
        tags:
          properties.Tags?.multi_select?.map((tag: any) => tag.name) ||
          properties.Labels?.multi_select?.map((tag: any) => tag.name) ||
          [],
        readTime:
          properties["Read Time"]?.number || properties.Duration?.number || 5,
        status: properties.Status?.select?.name || "Published",
        category:
          properties.Category?.select?.name ||
          properties.Type?.select?.name ||
          "General",
      };
    });

    console.log("post post value", posts)

    const totalPosts = allResults.results.length;
    const totalPages = Math.ceil(totalPosts / limit);

    return {
      posts,
      totalPages,
      currentPage: page,
      totalPosts,
      hasNextPage: page < totalPages,
      hasPreviousPage: page > 1,
    };
  } catch (error) {
    console.error("Error fetching blog posts:", error);
    return {
      posts: [],
      totalPages: 0,
      currentPage: page,
      totalPosts: 0,
      hasNextPage: false,
      hasPreviousPage: false,
    };
  }
}

export async function getBlogPost(slug: string): Promise<BlogPost | null> {
  try {
    const databases = await getBlogDatabases();
    if (databases.length === 0) return null;

    const databaseId = databases[0].id;

    // Get all posts and find by slug
    const response = await notion.databases.query({
      database_id: databaseId,
      page_size: 100,
    });

    const foundPage = response.results.find((page: any) => {
      const properties = page.properties;
      const title =
        properties.Name?.title?.[0]?.plain_text ||
        properties.Title?.title?.[0]?.plain_text ||
        "";
      const pageSlug =
        properties.Slug?.rich_text?.[0]?.plain_text ||
        title
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/(^-|-$)/g, "") ||
        page.id;
      return pageSlug === slug;
    });


    if (!foundPage) return null;

    const page: any = foundPage;
    const properties = page.properties;

    console.log("page content response", page);
    const title =
      properties.Name?.title?.[0]?.plain_text ||
      properties.Title?.title?.[0]?.plain_text ||
      "Untitled";

    const post: BlogPost = {
      id: page.id,
      title,
      slug:
        properties.Slug?.rich_text?.[0]?.plain_text ||
        title
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/(^-|-$)/g, "") ||
        page.id,
      excerpt:
        properties.Excerpt?.rich_text?.[0]?.plain_text ||
        properties.Description?.rich_text?.[0]?.plain_text ||
        "No excerpt available",
      coverImage:
        properties["Cover Image"]?.files?.[0]?.file?.url ||
        properties["Cover Image"]?.files?.[0]?.external?.url ||
        properties.Image?.files?.[0]?.file?.url ||
        properties.Image?.files?.[0]?.external?.url,
      publishedDate:
        properties.Date?.date?.start ||
        properties["Published Date"]?.date?.start ||
        properties["Created Date"]?.date?.start ||
        new Date().toISOString(),
      author:
        properties.Author?.people?.[0]?.name ||
        properties.Writer?.people?.[0]?.name ||
        "DropLeads Team",
      tags:
        properties.Tags?.multi_select?.map((tag: any) => tag.name) ||
        properties.Labels?.multi_select?.map((tag: any) => tag.name) ||
        [],
      readTime:
        properties["Read Time"]?.number || properties.Duration?.number || 5,
      status: properties.Status?.select?.name || "Published",
      category:
        properties.Category?.select?.name ||
        properties.Type?.select?.name ||
        "General",
    };

    // Fetch the full page content
  
    try {
      const pageContent = await notionClient.getPage(post?.id); 

      //notion.pages.retrieve({ page_id: post?.id });
      post.content = JSON.stringify(pageContent);
    } catch (contentError) {
      console.error("Error fetching page content:", contentError);
      post.content = "";
    }

    return post;
  } catch (error) {
    console.error("Error fetching blog post:", error);
    return null;
  }
}

export async function searchBlogPosts(
  query: string,
  page = 1,
  limit = 9
): Promise<PaginatedBlogPosts> {
  try {
    const databases = await getBlogDatabases();
    if (databases.length === 0) {
      return {
        posts: [],
        totalPages: 0,
        currentPage: page,
        totalPosts: 0,
        hasNextPage: false,
        hasPreviousPage: false,
      };
    }

    const databaseId = databases[0].id;
    const response = await notion.databases.query({
      database_id: databaseId,
      sorts: [
        {
          property: "Date",
          direction: "descending",
        },
      ],
      page_size: 100,
    });

    
    const allPosts: BlogPost[] = response.results.map((page: any) => {
      const properties = page.properties;

      const title =
        properties.Name?.title?.[0]?.plain_text ||
        properties.Title?.title?.[0]?.plain_text ||
        "Untitled";

      return {
        id: page.id,
        title,
        slug:
          properties.Slug?.rich_text?.[0]?.plain_text ||
          title
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, "-")
            .replace(/(^-|-$)/g, "") ||
          page.id,
        excerpt:
          properties.Excerpt?.rich_text?.[0]?.plain_text ||
          properties.Description?.rich_text?.[0]?.plain_text ||
          "No excerpt available",
        coverImage:
          properties["Cover Image"]?.files?.[0]?.file?.url ||
          properties["Cover Image"]?.files?.[0]?.external?.url ||
          properties.Image?.files?.[0]?.file?.url ||
          properties.Image?.files?.[0]?.external?.url,
        publishedDate:
          properties.Date?.date?.start ||
          properties["Published Date"]?.date?.start ||
          properties["Created Date"]?.date?.start ||
          new Date().toISOString(),
        author:
          properties.Author?.people?.[0]?.name ||
          properties.Writer?.people?.[0]?.name ||
          "DropLeads Team",
        tags:
          properties.Tags?.multi_select?.map((tag: any) => tag.name) ||
          properties.Labels?.multi_select?.map((tag: any) => tag.name) ||
          [],
        readTime:
          properties["Read Time"]?.number || properties.Duration?.number || 5,
        status: properties.Status?.select?.name || "Published",
        category:
          properties.Category?.select?.name ||
          properties.Type?.select?.name ||
          "General",
      };
    });

    // Filter posts based on search query
    const filteredPosts = allPosts.filter(
      (post) =>
        post.title.toLowerCase().includes(query.toLowerCase()) ||
        post.excerpt.toLowerCase().includes(query.toLowerCase()) ||
        post.tags.some((tag) => tag.toLowerCase().includes(query.toLowerCase()))
    );

    // Apply pagination
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedPosts = filteredPosts.slice(startIndex, endIndex);

    const totalPosts = filteredPosts.length;
    const totalPages = Math.ceil(totalPosts / limit);

    return {
      posts: paginatedPosts,
      totalPages,
      currentPage: page,
      totalPosts,
      hasNextPage: page < totalPages,
      hasPreviousPage: page > 1,
    };
  } catch (error) {
    console.error("Error searching blog posts:", error);
    return {
      posts: [],
      totalPages: 0,
      currentPage: page,
      totalPosts: 0,
      hasNextPage: false,
      hasPreviousPage: false,
    };
  }
}
