import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { fetchBlogPost } from "@/actions/blog-actions";
import { BlogPostClient } from "@/components/blog/blog-post-client";

interface BlogPostPageProps {
  params: Promise<{
    slug: string;
  }>;
}

export async function generateMetadata({
  params,
}: BlogPostPageProps): Promise<Metadata> {
  const { slug } = await params; // Await params
  const post = await fetchBlogPost(slug);

  if (!post) {
    return {
      title: "Post Not Found - DropLeads Blog",
      description: "The requested blog post could not be found.",
    };
  }

  return {
    title: `${post.title} - DropLeads Blog`,
    description: post.excerpt,
    keywords: post.tags,
    openGraph: {
      title: post.title,
      description: post.excerpt,
      url: `https://dropleads.io/blog/${post.slug}`,
      siteName: "DropLeads",
      images: post.coverImage
        ? [
            {
              url: post.coverImage,
              width: 1200,
              height: 630,
              alt: post.title,
            },
          ]
        : [],
      type: "article",
      publishedTime: post.publishedDate,
      authors: [post.author],
      tags: post.tags,
    },
    twitter: {
      card: "summary_large_image",
      title: post.title,
      description: post.excerpt,
      images: post.coverImage ? [post.coverImage] : [],
    },
    alternates: {
      canonical: `/blog/${post.slug}`,
    },
  };
}

export default async function BlogPostPage({ params }: BlogPostPageProps) {
  const { slug } = await params; // Await params
  const post = await fetchBlogPost(slug);

  
  if (!post) {
    notFound(); // Use notFound() to render the not-found file [^1]
  }

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    headline: post.title,
    description: post.excerpt,
    image: post.coverImage,
    datePublished: post.publishedDate,
    dateModified: post.publishedDate,
    author: {
      "@type": "Person",
      name: post.author,
    },
    publisher: {
      "@type": "Organization",
      name: "DropLeads",
      logo: {
        "@type": "ImageObject",
        url: "https://dropleads.io/logo.png",
      },
    },
    mainEntityOfPage: {
      "@type": "WebPage",
      "@id": `https://dropleads.io/blog/${post.slug}`,
    },
    keywords: post.tags.join(", "),
    wordCount: post.content ? post.content.split(" ").length : 0,
    timeRequired: `PT${post.readTime}M`,
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <BlogPostClient post={post} />
    </>
  );
}
