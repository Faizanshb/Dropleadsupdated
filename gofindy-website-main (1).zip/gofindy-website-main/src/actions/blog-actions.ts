"use server";

import {
  getBlogPosts,
  getBlogPost,
  getBlogCategories,
  searchBlogPosts,
} from "@/lib/notion";

export async function fetchBlogPosts(page = 1, limit = 9, category?: string) {
  return await getBlogPosts(page, limit, category);
}

export async function fetchBlogPost(slug: string) {
  return await getBlogPost(slug);
}

export async function fetchBlogCategories() {
  return await getBlogCategories();
}

export async function searchBlogPostsAction(
  query: string,
  page = 1,
  limit = 9
) {
  return await searchBlogPosts(query, page, limit);
}
